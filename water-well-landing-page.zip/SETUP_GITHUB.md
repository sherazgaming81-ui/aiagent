# GitHub Deployment Guide

This document explains how to push the Hawk Drilling landing page to your GitHub repository.

## Prerequisites

1. GitHub account (create one at https://github.com if needed)
2. Git installed on your machine
3. SSH key configured (or use HTTPS with personal access token)

## Step 1: Create a GitHub Repository

1. Go to https://github.com/new
2. Repository name: `hawk-drilling-landing` (or your preferred name)
3. Description: "Premium Water Well Drilling & Treatment Landing Page"
4. Choose Public or Private
5. DO NOT initialize with README (we have our own)
6. Click "Create repository"

## Step 2: Initialize Git in Your Project

If this is your first time:

```bash
# Copy the repository URL (HTTPS or SSH) from GitHub

# Navigate to project directory
cd /path/to/project

# Initialize git
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Hawk Drilling landing page with animations and 3D cards"

# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/hawk-drilling-landing.git

# Set branch name to main (if not already)
git branch -M main

# Push to GitHub
git push -u origin main
```

## Step 3: Push Changes

After making changes:

```bash
git add .
git commit -m "Your descriptive commit message"
git push origin main
```

## Step 4: Deploy to Vercel (Optional)

1. Go to https://vercel.com
2. Sign in with GitHub
3. Click "New Project"
4. Select your GitHub repository
5. Vercel will auto-detect Next.js
6. Click "Deploy"
7. Your site will be live at a `.vercel.app` URL

## Project Features

### Animations
- 50+ premium CSS text animations
- Smooth scroll-based entrance animations
- Hover effects with color transitions
- Infinite animations (pulse, glow, neon effects)

### 3D Cards
- Interactive service cards with flip animation
- 3D testimonial cards
- Hover effects with 3D perspective
- Click to flip and reveal additional content

### Components
- Hero section with premium branding
- Services grid with 3D cards
- Statistics section with animated numbers
- Testimonials with flip animations
- Interactive lead form (quote calculator)
- Water quality comparison
- Premium footer with brand logo

### Design System
- Luxury navy and gold color palette
- Serif typography for headings
- Tailwind CSS with custom animations
- Responsive design (mobile-first)
- Accessibility features

## File Structure

```
/components
  ├── HawkHero/              # Hero section
  ├── services.tsx           # Services grid
  ├── stats.tsx              # Statistics
  ├── testimonials.tsx       # Client testimonials
  ├── lead-form.tsx          # Quote calculator
  ├── water-comparison.tsx   # Quality comparison
  ├── footer.tsx             # Footer
  ├── interactive-service-card.tsx    # 3D service cards
  ├── interactive-testimonial-card.tsx # 3D testimonials
  └── 3d-card.tsx            # Base 3D card component

/styles
  └── hawk-luxury-sections.css  # All animations and styling

/lib
  └── animations.ts          # Animation utilities

/app
  └── page.tsx               # Home page
```

## Customization

### Colors
Edit color variables in `styles/hawk-luxury-sections.css`:
- `--hawk-dark`: Navy dark background
- `--hawk-gold`: Primary accent color
- `--hawk-gold-light`: Lighter gold
- `--hawk-white`: Text color
- `--hawk-muted`: Secondary text
- `--hawk-border`: Border color

### Text
Update company information in:
- `components/HawkHero/HawkHero.tsx`
- `components/footer.tsx`
- `components/services.tsx`
- `components/testimonials.tsx`

### Animations
Add or modify in `styles/hawk-luxury-sections.css` with 50+ pre-built animations.

## Dependencies

```json
{
  "dependencies": {
    "react": "^19",
    "next": "^16",
    "framer-motion": "^11",
    "three": "^0.185",
    "@react-three/fiber": "^9",
    "@react-three/drei": "^10",
    "lucide-react": "^0.366",
    "tailwindcss": "^4"
  }
}
```

## Support

For issues or questions:
1. Check existing GitHub issues
2. Create a new issue with detailed description
3. Include screenshots or screen recordings

## License

MIT License - Feel free to use, modify, and distribute.

---

**Questions?** Visit https://github.com/YOUR_USERNAME/hawk-drilling-landing/issues
