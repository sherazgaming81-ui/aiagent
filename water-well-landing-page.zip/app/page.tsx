import "@/styles/hawk-luxury-sections.css"
import HawkHero from '@/components/HawkHero/HawkHero'
import { LeadForm } from '@/components/lead-form'
import { Services } from '@/components/services'
import { Stats } from '@/components/stats'
import { WaterComparison } from '@/components/water-comparison'
import { ServiceArea } from '@/components/service-area'
import { Testimonials } from '@/components/testimonials'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <>
      <HawkHero phoneDisplay="(888) 429-5011" phoneHref="+18884295011" showNgwa={false} />
      <main className="hawk-site-sections">
        <LeadForm />
        <Services />
        <Stats />
        <WaterComparison />
        <ServiceArea />
        <Testimonials />
        <Footer />
      </main>
    </>
  )
}
