// Animation variants for Framer Motion
export const animationVariants = {
  // Fade + Slide Up
  fadeInUp: {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  },

  // Scale + Fade
  scaleIn: {
    hidden: { opacity: 0, scale: 0.95 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.5, ease: 'easeOut' },
    },
  },

  // Rotate + Fade (for testimonials)
  rotateIn: {
    hidden: { opacity: 0, rotate: -8, scale: 0.9 },
    visible: {
      opacity: 1,
      rotate: 0,
      scale: 1,
      transition: { duration: 0.7, ease: 'easeOut' },
    },
  },

  // Stagger Container for cards
  containerVariants: {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1,
      },
    },
  },

  // Individual Item (for stagger)
  itemVariants: {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: 'easeOut' },
    },
  },

  // Text reveal line by line
  textVariants: {
    hidden: { opacity: 0, y: 8 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4, ease: 'easeOut' },
    },
  },

  // Hover Lift effect
  hoverLift: {
    whileHover: { y: -8, transition: { duration: 0.3 } },
    whileTap: { y: 0 },
  },

  // Button Hover Scale
  buttonHover: {
    whileHover: { scale: 1.05 },
    whileTap: { scale: 0.98 },
  },

  // Card Hover Scale
  cardHover: {
    whileHover: { scale: 1.03, y: -12 },
  },

  // Section title animation
  titleVariants: {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  },

  // Description text animation
  descriptionVariants: {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, delay: 0.1, ease: 'easeOut' },
    },
  },
};

// Intersection Observer options for scroll animations
export const scrollAnimationOptions = {
  initial: 'hidden',
  whileInView: 'visible',
  viewport: { once: true, amount: 0.2 },
};

// Count-up animation for stats
export const createCountUpVariant = (duration: number = 2) => ({
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: 'easeOut' },
  },
});
