'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { LucideIcon, ArrowRight } from 'lucide-react'

interface InteractiveServiceCardProps {
  icon: LucideIcon
  title: string
  description: string
  features: string[]
}

export function InteractiveServiceCard({
  icon: Icon,
  title,
  description,
  features,
}: InteractiveServiceCardProps) {
  const [isFlipped, setIsFlipped] = useState(false)
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      className="h-full cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onTap={() => setIsFlipped(!isFlipped)}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <div
        style={{
          perspective: '1500px',
          transformStyle: 'preserve-3d',
          position: 'relative',
          width: '100%',
          height: '100%',
          minHeight: '400px',
        }}
      >
        {/* 3D Card Container */}
        <motion.div
          style={{
            transformStyle: 'preserve-3d',
            width: '100%',
            height: '100%',
          }}
          animate={{
            rotateY: isFlipped ? 180 : 0,
            rotateX: isHovered ? 5 : 0,
          }}
          transition={{
            rotateY: { duration: 0.6, type: 'spring', stiffness: 100 },
            rotateX: { duration: 0.3 },
          }}
        >
          {/* Front Side */}
          <div
            className="absolute w-full h-full bg-gradient-to-br from-navy-900/80 to-navy-950/90 backdrop-blur-xl rounded-2xl border border-gold/30 p-8 flex flex-col justify-between shadow-2xl hover:shadow-gold/20 hover:border-gold/60 transition-all"
            style={{
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
            }}
          >
            {/* Icon */}
            <motion.div
              animate={{
                y: isHovered ? -10 : 0,
                rotateZ: isHovered ? 10 : 0,
              }}
              transition={{ duration: 0.3 }}
            >
              <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-gold/20 to-gold/5 flex items-center justify-center mb-6 border border-gold/30">
                <Icon className="w-8 h-8 text-gold" />
              </div>
            </motion.div>

            {/* Content */}
            <div className="flex-1">
              <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-gold transition-colors">
                {title}
              </h3>
              <p className="text-gray-300 text-sm leading-relaxed mb-6">{description}</p>
            </div>

            {/* Call to action */}
            <div>
              <motion.button
                className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors font-semibold"
                whileHover={{ x: 5 }}
              >
                Learn More <ArrowRight className="w-4 h-4" />
              </motion.button>
              <div className="text-xs text-gold/60 mt-3">Click card to see details →</div>
            </div>
          </div>

          {/* Back Side */}
          <div
            className="absolute w-full h-full bg-gradient-to-br from-gold/15 to-gold/5 backdrop-blur-xl rounded-2xl border border-gold/50 p-8 flex flex-col justify-between shadow-2xl shadow-gold/30"
            style={{
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              transform: 'rotateY(180deg)',
            }}
          >
            {/* Header */}
            <div>
              <h3 className="text-2xl font-bold text-gold mb-4">Key Features</h3>
              <p className="text-white/90 text-sm mb-6">Everything you need to know:</p>
            </div>

            {/* Features List */}
            <ul className="space-y-3 flex-1">
              {features.map((feature, idx) => (
                <motion.li
                  key={idx}
                  className="flex items-start gap-3 text-white/80"
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <span className="text-gold font-bold mt-0.5">✓</span>
                  <span className="text-sm">{feature}</span>
                </motion.li>
              ))}
            </ul>

            {/* Footer */}
            <div className="text-xs text-gold/60 text-center">Click to go back ←</div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  )
}
