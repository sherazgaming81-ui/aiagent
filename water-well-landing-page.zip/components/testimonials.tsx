'use client'

import { motion } from 'framer-motion'
import { Star } from 'lucide-react'
import { animationVariants, scrollAnimationOptions } from '@/lib/animations'
import { InteractiveTestimonialCard } from '@/components/interactive-testimonial-card'

export function Testimonials() {
  const testimonials = [
    {
      name: 'James M.',
      location: 'Homeowner, Saratoga Springs',
      text: 'They came early during our emergency situation! Professional, courteous, and the water quality has been perfect ever since. Highly recommend.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    },
    {
      name: 'Sarah K.',
      location: 'Business Owner, Albany',
      text: 'We switched all our commercial facilities to Hawk Drilling. Their 20-year warranty and maintenance support gives us complete peace of mind.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    },
    {
      name: 'Michael R.',
      location: 'Farm Manager, Glens Falls',
      text: 'After 40 years in farming, I know quality when I see it. Hawk&apos;s drilling and treatment systems are top-tier. Worth every penny.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    },
  ]

  return (
    <section id="testimonials" className="hawk-section">
      <div className="hawk-section-inner">
        {/* Section Header */}
        <motion.div
          className="hawk-section-header"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          <motion.div className="hawk-section-eyebrow" variants={animationVariants.itemVariants}>
            CLIENT TESTIMONIALS
          </motion.div>
          <motion.h2 className="hawk-section-title" variants={animationVariants.itemVariants}>
            What Our <em>Customers</em> Say
          </motion.h2>
          <motion.p className="hawk-section-description" variants={animationVariants.itemVariants}>
            Thousands of satisfied customers trust Hawk Drilling for their water needs
          </motion.p>
        </motion.div>

        {/* Testimonials Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          {testimonials.map((testimonial, index) => (
            <InteractiveTestimonialCard
              key={index}
              name={testimonial.name}
              location={testimonial.location}
              text={testimonial.text}
              rating={testimonial.rating}
              avatar={testimonial.avatar}
            />
          ))}
        </motion.div>
      </div>
    </section>
  )
}
