'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Droplet, Zap, Beaker, TestTube } from 'lucide-react'
import { animationVariants } from '@/lib/animations'

export function LeadForm() {
  const [step, setStep] = useState(1)
  const [selectedService, setSelectedService] = useState<string | null>(null)

  const services = [
    { id: 'drilling', label: 'Water Well Drilling', icon: Droplet, description: 'Deep bedrock wells' },
    { id: 'pumps', label: 'Well Pumps & Systems', icon: Zap, description: 'Submersible pumps' },
    { id: 'treatment', label: 'Water Treatment', icon: Beaker, description: 'Water softening' },
    { id: 'testing', label: 'Water Testing', icon: TestTube, description: 'Lab analysis' },
  ]

  const pageVariants = {
    enter: { opacity: 0, y: 20 },
    center: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 },
  }

  return (
    <section className="hawk-section hawk-quote-section">
      <div className="hawk-quote-container" style={{ maxWidth: '800px' }}>
          <motion.div
            className="hawk-quote-panel"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
          {/* Progress Indicator */}
          <div className="hawk-stepper">
            {[1, 2, 3].map((stepNum, idx) => (
              <div key={stepNum} className={`hawk-step ${step === stepNum ? 'is-active' : step > stepNum ? 'is-complete' : ''}`}>
                <div className="hawk-step-number">{stepNum}</div>
                <span>{stepNum === 1 ? 'Service' : stepNum === 2 ? 'Details' : 'Quote'}</span>
                {idx < 2 && <div className="hawk-step-line" />}
              </div>
            ))}
          </div>

          {/* Step 1: Service Selection */}
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                className="space-y-6"
                variants={pageVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.4 }}
              >
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
                  <h3 className="hawk-quote-title">What service do you need?</h3>
                  <p className="hawk-quote-description">Select the service that best matches your needs</p>
                </motion.div>

                <motion.div
                  className="hawk-option-grid"
                  variants={animationVariants.containerVariants}
                  initial="hidden"
                  animate="visible"
                >
                  {services.map((service, idx) => {
                    const Icon = service.icon
                    return (
                      <motion.button
                        key={service.id}
                        onClick={() => setSelectedService(service.id)}
                        className={`hawk-option-card ${selectedService === service.id ? 'is-selected' : ''}`}
                        variants={animationVariants.itemVariants}
                        whileHover={{ scale: 1.05, y: -4 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <motion.div
                          whileHover={{ rotate: 5, scale: 1.15 }}
                        >
                          <Icon className="hawk-option-icon" />
                        </motion.div>
                        <h3>{service.label}</h3>
                        <p>{service.description}</p>
                      </motion.button>
                    )
                  })}
                </motion.div>

                <button
                  onClick={() => setStep(2)}
                  disabled={!selectedService}
                  className="hawk-button w-full"
                  style={{ opacity: !selectedService ? 0.5 : 1 }}
                >
                  Continue to Step 2
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Step 2: Details */}
          <AnimatePresence mode="wait">
            {step === 2 && (
              <motion.div
                className="space-y-6"
                variants={pageVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.4 }}
              >
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
                  <h3 className="hawk-quote-title">Tell us more</h3>
                  <p className="hawk-quote-description">We need some basic information to provide an accurate quote</p>
                </motion.div>

                <motion.div
                  className="hawk-form-grid"
                  variants={animationVariants.containerVariants}
                  initial="hidden"
                  animate="visible"
                >
                  {[
                    { label: 'Full Name *', placeholder: 'John Smith', type: 'text' },
                    { label: 'Email *', placeholder: 'john@example.com', type: 'email' },
                    { label: 'Phone *', placeholder: '(518) 555-0100', type: 'tel' },
                  ].map((field, idx) => (
                    <motion.div key={field.label} className="hawk-form-field" variants={animationVariants.itemVariants}>
                      <label>{field.label}</label>
                      <motion.input
                        type={field.type}
                        placeholder={field.placeholder}
                        whileFocus={{
                          scale: 1.02,
                          boxShadow: '0 0 0 3px rgba(213, 169, 79, 0.1)',
                        }}
                        transition={{ duration: 0.2 }}
                      />
                    </motion.div>
                  ))}
                </motion.div>

                <div style={{ display: 'flex', gap: '12px' }}>
                  <button onClick={() => setStep(1)} className="hawk-button--secondary" style={{ flex: 1 }}>
                    Back
                  </button>
                  <button onClick={() => setStep(3)} className="hawk-button" style={{ flex: 1 }}>
                    Get Free Quote
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Step 3: Quote */}
          <AnimatePresence mode="wait">
            {step === 3 && (
              <motion.div
                className="space-y-6 text-center"
                variants={pageVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.4 }}
              >
                <motion.div
                  style={{ textAlign: 'center', color: 'var(--hawk-gold)', fontSize: '3rem' }}
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5, type: 'spring', stiffness: 200 }}
                >
                  ✓
                </motion.div>
                <motion.h3
                  className="hawk-quote-title"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  Quote Request Submitted!
                </motion.h3>
                <motion.p
                  className="hawk-quote-description"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  Thank you for your submission. Our team will contact you within 24 hours with a personalized quote and next steps.
                </motion.p>
                <button
                  onClick={() => {
                    setStep(1)
                    setSelectedService(null)
                  }}
                  className="hawk-button"
                  style={{ display: 'block', margin: '0 auto' }}
                >
                  Submit Another Request
                </button>
              </motion.div>
            )}
          </AnimatePresence>
          </motion.div>
      </div>
    </section>
  )
}
