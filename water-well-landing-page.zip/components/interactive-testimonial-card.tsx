'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Star } from 'lucide-react'

interface InteractiveTestimonialCardProps {
  name: string
  location: string
  text: string
  rating: number
  avatar: string
}

export function InteractiveTestimonialCard({
  name,
  location,
  text,
  rating,
  avatar,
}: InteractiveTestimonialCardProps) {
  const [isFlipped, setIsFlipped] = useState(false)
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      className="h-full cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onTap={() => setIsFlipped(!isFlipped)}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
    >
      <div
        style={{
          perspective: '1500px',
          transformStyle: 'preserve-3d',
          position: 'relative',
          width: '100%',
          height: '100%',
          minHeight: '350px',
        }}
      >
        {/* 3D Card Container */}
        <motion.div
          style={{
            transformStyle: 'preserve-3d',
            width: '100%',
            height: '100%',
          }}
          animate={{
            rotateY: isFlipped ? 180 : 0,
            rotateX: isHovered ? -5 : 0,
          }}
          transition={{
            rotateY: { duration: 0.6, type: 'spring', stiffness: 100 },
            rotateX: { duration: 0.3 },
          }}
        >
          {/* Front Side - Testimonial */}
          <div
            className="absolute w-full h-full bg-white/80 backdrop-blur-xl rounded-2xl border border-white/20 p-8 flex flex-col justify-between shadow-lg hover:shadow-2xl transition-shadow group"
            style={{
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
            }}
          >
            {/* Star Rating */}
            <motion.div
              className="flex gap-1 mb-4"
              animate={{
                scale: isHovered ? 1.1 : 1,
              }}
              transition={{ duration: 0.3 }}
            >
              {[...Array(rating)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.1 }}
                >
                  <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                </motion.div>
              ))}
            </motion.div>

            {/* Quote */}
            <motion.p
              className="text-slate-700 flex-1 italic leading-relaxed font-medium mb-6"
              animate={{
                color: isHovered ? '#d5a94f' : '#3f464e',
              }}
            >
              &quot;{text}&quot;
            </motion.p>

            {/* Author */}
            <div className="flex items-center gap-4 pt-4 border-t border-slate-200">
              <motion.img
                src={avatar}
                alt={name}
                className="w-12 h-12 rounded-full object-cover border-2 border-amber-300/30"
                whileHover={{ scale: 1.15, rotate: 5 }}
              />
              <div className="flex-1">
                <p className="font-semibold text-slate-900 group-hover:text-amber-600 transition-colors">
                  {name}
                </p>
                <p className="text-sm text-slate-600">{location}</p>
              </div>
            </div>

            {/* CTA */}
            <div className="text-xs text-slate-400 mt-4 text-center">
              Click card for more →
            </div>
          </div>

          {/* Back Side - Extended Testimonial */}
          <div
            className="absolute w-full h-full bg-gradient-to-br from-amber-50/90 to-amber-100/80 backdrop-blur-xl rounded-2xl border border-amber-200/50 p-8 flex flex-col justify-between shadow-2xl shadow-amber-200/20"
            style={{
              backfaceVisibility: 'hidden',
              WebkitBackfaceVisibility: 'hidden',
              transform: 'rotateY(180deg)',
            }}
          >
            {/* Header */}
            <div>
              <h3 className="text-xl font-bold text-amber-900 mb-2">Customer Story</h3>
              <div className="h-1 w-12 bg-gradient-to-r from-amber-500 to-amber-300 rounded"></div>
            </div>

            {/* Extended Content */}
            <div className="flex-1 my-4">
              <p className="text-amber-900 text-sm leading-relaxed font-medium mb-4">
                {text}
              </p>
              <div className="space-y-2">
                <p className="text-amber-800 text-xs">
                  <span className="font-bold">Service Quality:</span> ⭐⭐⭐⭐⭐
                </p>
                <p className="text-amber-800 text-xs">
                  <span className="font-bold">Professional Team:</span> ⭐⭐⭐⭐⭐
                </p>
                <p className="text-amber-800 text-xs">
                  <span className="font-bold">Would Recommend:</span> Yes, absolutely!
                </p>
              </div>
            </div>

            {/* Author Info Again */}
            <div className="border-t border-amber-200 pt-4">
              <p className="font-bold text-amber-900">{name}</p>
              <p className="text-xs text-amber-700">{location}</p>
              <div className="text-xs text-amber-600 mt-2">← Click to go back</div>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  )
}
