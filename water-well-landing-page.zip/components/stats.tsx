'use client'

import { motion } from 'framer-motion'
import { animationVariants, scrollAnimationOptions } from '@/lib/animations'

export function Stats() {
  const stats = [
    { number: 99, unit: 'Years', label: 'Family Heritage', description: 'Serving the region with excellence' },
    { number: 75000, unit: '+', label: 'Satisfied Customers', description: 'Trusted families and businesses' },
    { number: 20, unit: 'Year', label: 'Maximum Warranty', description: 'Industry-leading coverage' },
    { number: 10, unit: '+', label: 'Counties Served', description: 'Proudly serving the region' },
  ]

  return (
    <section id="why-us" className="hawk-section hawk-legacy-section">
      <div className="hawk-section-inner">
        {/* Section Header */}
        <motion.div
          className="hawk-section-header"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          <motion.div className="hawk-section-eyebrow" variants={animationVariants.itemVariants}>
            OUR LEGACY
          </motion.div>
          <motion.h2 className="hawk-section-title" variants={animationVariants.itemVariants}>
            The <em>Legacy</em> of Trust
          </motion.h2>
          <motion.p className="hawk-section-description" variants={animationVariants.itemVariants}>
            Nearly a century of family-owned excellence in water well drilling and treatment
          </motion.p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          className="hawk-stats-grid"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              className={`hawk-stat-card ${index === 0 ? 'hawk-stat-card--featured' : ''}`}
              variants={animationVariants.itemVariants}
            >
              <motion.div
                className="hawk-stat-number"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                {stat.number.toLocaleString()}
              </motion.div>
              <div className="hawk-stat-unit">{stat.unit}</div>
              <h3>{stat.label}</h3>
              <p>{stat.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
