'use client'

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { ArrowRight, Star, ShieldCheck, Award, Droplet } from 'lucide-react'

export function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: 'easeOut' },
    },
  }

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 overflow-hidden pt-20">
      {/* Animated Grid Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,.05)_1px,transparent_1px)] bg-[size:40px_40px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,.1)_0%,transparent_50%)]" />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Left Content */}
          <motion.div className="space-y-8" variants={containerVariants}>
            {/* Badge */}
            <motion.div
              className="inline-flex items-center gap-2 bg-accent/20 backdrop-blur-md px-4 py-2 rounded-full border border-accent/40"
              variants={itemVariants}
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(245, 158, 11, 0.3)' }}
            >
              <Award className="w-4 h-4 text-accent" />
              <span className="text-sm font-semibold text-accent">5th Generation Expertise Since 1927</span>
            </motion.div>

            {/* Headline */}
            <motion.div variants={itemVariants}>
              <motion.h1
                className="text-5xl lg:text-6xl font-extrabold leading-tight text-balance mb-4 bg-gradient-to-r from-white via-white to-accent bg-clip-text text-transparent tracking-tighter"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, ease: 'easeOut' }}
              >
                Pure Water, Right From The Earth.
              </motion.h1>
              <motion.h2
                className="text-4xl lg:text-5xl font-extrabold leading-tight text-balance bg-gradient-to-r from-accent to-white bg-clip-text text-transparent tracking-tighter"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.2, ease: 'easeOut' }}
              >
                Done Right The First Time.
              </motion.h2>
            </motion.div>

            {/* Subheadline */}
            <motion.p
              className="text-lg text-white/70 leading-relaxed max-w-lg"
              variants={itemVariants}
            >
              Trusted by over 75,000 families and businesses across the region. Certified state rig operators with industry-leading 20-year warranties.
            </motion.p>

            {/* Trust Row */}
            <motion.div className="flex flex-col sm:flex-row gap-6" variants={itemVariants}>
              <motion.div className="flex items-center gap-2" whileHover={{ scale: 1.05 }}>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                  ))}
                </div>
                <div>
                  <div className="font-semibold text-white">4.8★ Google Rating</div>
                  <div className="text-sm text-white/60">(150+ Reviews)</div>
                </div>
              </motion.div>
              <motion.div className="flex items-center gap-2 text-sm" whileHover={{ scale: 1.05 }}>
                <motion.div className="w-2 h-2 bg-green-400 rounded-full" animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 1.5, repeat: Infinity }} />
                <div className="font-semibold text-white">Licensed & Insured</div>
              </motion.div>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div className="flex flex-col sm:flex-row gap-4 pt-4" variants={itemVariants}>
              <motion.div
                className="w-full sm:w-auto"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  size="lg"
                  className="w-full bg-gradient-to-r from-accent to-amber-600 hover:from-accent hover:to-amber-700 text-white font-semibold shadow-lg hover:shadow-amber-500/50 transition-all duration-300"
                >
                  Get Your Free Quote
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </motion.div>
              <motion.div
                className="w-full sm:w-auto"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  size="lg"
                  className="w-full border-2 border-white/20 text-white hover:bg-white/10 backdrop-blur-md font-semibold"
                >
                  View Services
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Right Image Placeholder */}
          <motion.div
            className="relative h-96 lg:h-full hidden lg:block"
            variants={itemVariants}
          >
            <motion.div
              className="absolute inset-0 rounded-3xl overflow-hidden border border-white/10 shadow-2xl"
              whileHover={{ scale: 1.02, borderColor: 'rgba(245, 158, 11, 0.5)' }}
              transition={{ duration: 0.3 }}
            >
              <img
                src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=600&h=800&fit=crop"
                alt="Professional water well drilling rig"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent" />
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
