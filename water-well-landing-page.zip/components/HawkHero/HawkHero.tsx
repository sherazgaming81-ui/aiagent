import styles from "./HawkHero.module.css";

function HawkMark() {
  return (
    <svg
      viewBox="0 0 64 64"
      aria-hidden="true"
      className={styles.logoMark}
    >
      <path
        d="M32 31C22 17 10 13 3 13c5 9 12 15 22 19-8-1-14 1-19 5 8 3 15 4 23 1l3 13 3-13c8 3 15 2 23-1-5-4-11-6-19-5 10-4 17-10 22-19-7 0-19 4-29 18Z"
        fill="currentColor"
      />
      <path
        d="m25 48 7 8 7-8-7 3-7-3Z"
        fill="currentColor"
        opacity=".75"
      />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M7.3 2.8 10 7.4 7.9 9.1c1.2 2.7 3.3 4.8 6 6l1.7-2.1 4.6 2.7c.5.3.8.9.6 1.5l-.6 2.7c-.2.7-.8 1.2-1.5 1.2C10 21.1 2.9 14 2.9 5.3c0-.7.5-1.3 1.2-1.5l2.7-.6c.6-.2 1.2.1 1.5.6Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M5 12h13M14 7l5 5-5 5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function CheckBadge() {
  return (
    <svg viewBox="0 0 52 52" aria-hidden="true">
      <path
        d="M26 3 43 10v13c0 12-7 21-17 26C16 44 9 35 9 23V10l17-7Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="m18 26 5 5 11-12"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function StarBadge() {
  return (
    <svg viewBox="0 0 64 64" aria-hidden="true">
      <circle
        cx="32"
        cy="32"
        r="27"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path
        d="m32 14 3 9h10l-8 6 3 9-8-6-8 6 3-9-8-6h10l3-9Z"
        fill="currentColor"
      />
      <path
        d="M14 45h36"
        stroke="currentColor"
        strokeWidth="1.5"
        opacity=".65"
      />
    </svg>
  );
}

export default function HawkHero({
  phoneDisplay = "(888) 429-5011",
  phoneHref = "+18884295011",
  showNgwa = false,
}) {
  return (
    <section className={styles.hero} aria-labelledby="hawk-hero-heading">
      <div className={styles.media} aria-hidden="true">
        <div className={styles.waterMedia} />
        <div className={styles.rigMedia} />
        <div className={styles.mediaOverlay} />
        <div className={styles.waterGlow} />
      </div>

      <header className={styles.header}>
        <a className={styles.brand} href="/" aria-label="Hawk Drilling home">
          <HawkMark />
          <span>Hawk Drilling</span>
        </a>

        <nav className={styles.desktopNav} aria-label="Primary navigation">
          <a href="#about">About</a>
          <a href="#services">Services</a>
          <a href="#technology">Technology</a>
          <a href="#process">Our Process</a>
          <a href="#projects">Projects</a>
          <a href="#contact">Contact</a>
        </nav>

        <a
          className={styles.phoneButton}
          href={`tel:${phoneHref}`}
          aria-label={`Call Hawk Drilling at ${phoneDisplay}`}
        >
          <PhoneIcon />
          <span>{phoneDisplay}</span>
        </a>

        <details className={styles.mobileMenu}>
          <summary aria-label="Open navigation menu">
            <span />
            <span />
            <span />
          </summary>

          <nav aria-label="Mobile navigation">
            <a href="#about">About</a>
            <a href="#services">Services</a>
            <a href="#technology">Technology</a>
            <a href="#process">Our Process</a>
            <a href="#projects">Projects</a>
            <a href="#contact">Contact</a>
            <a href={`tel:${phoneHref}`}>Call {phoneDisplay}</a>
          </nav>
        </details>
      </header>

      <div className={styles.headerDivider} />

      <div className={styles.inner}>
        <div className={styles.content}>
          <div className={styles.eyebrow}>
            <span />
            <p>Precision beneath the surface. Purity above all.</p>
          </div>

          <h1 id="hawk-hero-heading" className={styles.heading}>
            Pure Water.
            <br />
            <span>Precision</span> Drilling.
          </h1>

          <div className={styles.decorativeDivider}>
            <span />
            <b aria-hidden="true">⌄</b>
            <span />
          </div>

          <p className={styles.description}>
            Luxury water well drilling and advanced filtration solutions for
            discerning homeowners, estates, farms, and businesses.
          </p>

          <div className={styles.actions}>
            <a className={styles.primaryAction} href="#contact">
              <span>Request a Consultation</span>
              <ArrowIcon />
            </a>

            <a className={styles.secondaryAction} href="#services">
              <span>View Services</span>
              <ArrowIcon />
            </a>
          </div>

          <div className={styles.trustSection}>
            <div className={styles.trustIntro}>
              <span>Trusted.</span>
              <span>Accredited.</span>
              <span>Certified.</span>
            </div>

            <div className={styles.trustDivider} />

            {showNgwa ? (
              <div className={styles.credential}>
                <div className={styles.silverBadge}>
                  <strong>NGWA</strong>
                  <small>Member</small>
                </div>
                <div className={styles.credentialCopy}>
                  <strong>Proud Member</strong>
                  <span>NGWA</span>
                </div>
              </div>
            ) : (
              <div className={styles.credential}>
                <div className={styles.silverBadge}>
                  <strong>PRO</strong>
                  <small>Standards</small>
                </div>
                <div className={styles.credentialCopy}>
                  <strong>Professional</strong>
                  <span>Industry Standards</span>
                </div>
              </div>
            )}

            <div className={styles.credential}>
              <div className={styles.goldIcon}>
                <CheckBadge />
              </div>
              <div className={styles.credentialCopy}>
                <strong>Fully Licensed</strong>
                <span>&amp; Insured</span>
              </div>
            </div>

            <div className={styles.credential}>
              <div className={styles.goldIcon}>
                <StarBadge />
              </div>
              <div className={styles.credentialCopy}>
                <strong>Premium Service</strong>
                <span>Client Focused</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
