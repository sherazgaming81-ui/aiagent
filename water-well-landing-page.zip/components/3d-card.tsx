'use client'

import { useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import * as THREE from 'three'

interface Card3DProps {
  frontContent: React.ReactNode
  backContent: React.ReactNode
  isFlipped: boolean
  title: string
  description: string
}

function CardMesh({ isFlipped }: { isFlipped: boolean }) {
  const meshRef = useRef<THREE.Group>(null)
  const [rotation, setRotation] = useState(0)

  useFrame(() => {
    if (meshRef.current) {
      if (isFlipped) {
        meshRef.current.rotation.y = Math.PI
      } else {
        meshRef.current.rotation.y = 0
      }
      meshRef.current.rotation.x += 0.0002
    }
  })

  return (
    <group ref={meshRef}>
      <mesh position={[0, 0, 0]} scale={[2, 2.8, 0.1]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial
          color={'#0f2432'}
          metalness={0.4}
          roughness={0.7}
          emissive={'#d5a94f'}
          emissiveIntensity={0.1}
        />
      </mesh>
    </group>
  )
}

export function Card3D({ frontContent, backContent, isFlipped, title }: Card3DProps) {
  return (
    <div className="relative w-full h-full bg-gradient-to-br from-navy-900 to-navy-950 rounded-2xl border border-gold/20 overflow-hidden shadow-2xl">
      <div className="absolute inset-0 perspective" style={{ perspective: '1000px' }}>
        <Canvas
          camera={{ position: [0, 0, 3], fov: 50 }}
          style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
        >
          <ambientLight intensity={0.6} />
          <pointLight position={[10, 10, 10]} intensity={0.8} />
          <pointLight position={[-10, -10, 10]} intensity={0.4} color="#d5a94f" />
          <CardMesh isFlipped={isFlipped} />
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={2} />
        </Canvas>
      </div>

      {/* Content Overlay */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center p-8 text-center backdrop-blur-sm">
        <div
          style={{
            transformStyle: 'preserve-3d',
            transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
            transition: 'transform 0.6s ease-out',
            backfaceVisibility: 'hidden',
          }}
        >
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-white">{title}</h3>
            <div className="text-gray-300">{frontContent}</div>
          </div>
        </div>

        {/* Back Content - Hidden initially */}
        <div
          style={{
            transformStyle: 'preserve-3d',
            transform: isFlipped ? 'rotateY(0deg)' : 'rotateY(-180deg)',
            transition: 'transform 0.6s ease-out',
            backfaceVisibility: 'hidden',
            position: 'absolute',
            inset: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '32px',
            textAlign: 'center',
          }}
        >
          <div className="space-y-4">
            <h3 className="text-2xl font-bold text-gold">Details</h3>
            <div className="text-gray-200 text-sm">{backContent}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Simple 3D Card without Three.js Canvas (lighter weight)
export function Card3DLite({
  frontContent,
  backContent,
  isFlipped,
  title,
  description,
}: Card3DProps) {
  return (
    <div
      className="relative w-full h-full cursor-pointer"
      style={{
        perspective: '1200px',
        transformStyle: 'preserve-3d',
      }}
    >
      <div
        style={{
          transformStyle: 'preserve-3d',
          transform: isFlipped ? 'rotateY(180deg) rotateX(5deg)' : 'rotateY(0deg)',
          transition: 'transform 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
          width: '100%',
          height: '100%',
        }}
      >
        {/* Front Face */}
        <div
          className="absolute w-full h-full bg-gradient-to-br from-navy-900/90 to-navy-950/90 backdrop-blur-xl rounded-2xl border border-gold/30 p-8 flex flex-col items-center justify-center shadow-2xl hover:shadow-gold/20"
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
          }}
        >
          <div className="space-y-4 text-center">
            <div className="text-4xl font-bold text-gold mb-2">✨</div>
            <h3 className="text-2xl font-bold text-white">{title}</h3>
            <p className="text-gray-300 text-sm leading-relaxed">{description}</p>
            <div className="pt-4 text-xs text-gold/80">Click to reveal details</div>
          </div>
        </div>

        {/* Back Face */}
        <div
          className="absolute w-full h-full bg-gradient-to-br from-gold/10 to-gold/5 backdrop-blur-xl rounded-2xl border border-gold/50 p-8 flex flex-col items-center justify-center shadow-2xl shadow-gold/20"
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
          }}
        >
          <div className="space-y-4 text-center">
            <div className="text-4xl font-bold text-gold mb-2">→</div>
            <h3 className="text-2xl font-bold text-gold">More Details</h3>
            <div className="text-white text-sm leading-relaxed">{frontContent}</div>
            <div className="pt-4 text-xs text-gold/80">Click to go back</div>
          </div>
        </div>
      </div>
    </div>
  )
}
