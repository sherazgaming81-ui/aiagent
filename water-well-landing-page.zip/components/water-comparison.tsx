'use client'

import { motion } from 'framer-motion'
import { Droplet, CheckCircle } from 'lucide-react'
import { animationVariants, scrollAnimationOptions } from '@/lib/animations'

export function WaterComparison() {
  const itemVariants = {
    hidden: { opacity: 0, x: -30 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.6 } },
  }

  return (
    <section className="hawk-section">
      <div className="hawk-section-inner">
        {/* Section Header */}
        <motion.div
          className="hawk-section-header"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          <motion.div className="hawk-section-eyebrow" variants={animationVariants.itemVariants}>
            WATER QUALITY
          </motion.div>
          <motion.h2 className="hawk-section-title" variants={animationVariants.itemVariants}>
            The <em>Hawk</em> Difference
          </motion.h2>
          <motion.p className="hawk-section-description" variants={animationVariants.itemVariants}>
            See how our advanced treatment systems transform water quality
          </motion.p>
        </motion.div>

        {/* Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Before */}
          <motion.div className="group" variants={itemVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.div
              className="bg-gradient-to-br from-orange-900/30 to-orange-950/20 rounded-2xl p-8 border-2 border-orange-500/30 mb-6 h-64 flex flex-col items-center justify-center relative overflow-hidden backdrop-blur-xl"
              whileHover={{ borderColor: 'rgba(249, 115, 22, 0.6)', boxShadow: '0 0 30px rgba(249, 115, 22, 0.2)' }}
              transition={{ duration: 0.3 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-orange-500/10 to-transparent"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <motion.div className="mb-4 relative z-10" animate={{ y: [0, -10, 0] }} transition={{ duration: 3, repeat: Infinity }}>
                <Droplet className="w-16 h-16 text-orange-400 opacity-70" />
              </motion.div>
              <div className="text-center relative z-10">
                <p className="text-sm font-semibold text-orange-300 mb-2">Untreated Well Water</p>
                <div className="text-xs text-orange-300/80 space-y-1">
                  <p>• High iron content</p>
                  <p>• Hard minerals</p>
                  <p>• Cloudy appearance</p>
                </div>
              </div>
            </motion.div>
            <motion.div className="space-y-2">
              <p className="text-sm font-semibold text-white">Common Issues:</p>
              <ul className="space-y-2">
                {['Rusty discoloration', 'Unpleasant odor', 'Appliance buildup'].map((issue, i) => (
                  <motion.li
                    key={issue}
                    className="flex items-start gap-2 text-sm text-white/70"
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <span className="text-orange-400 mt-0.5">×</span>
                    <span>{issue}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          </motion.div>

          {/* After */}
          <motion.div
            className="group"
            variants={itemVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <motion.div
              className="bg-gradient-to-br from-blue-900/30 to-cyan-950/20 rounded-2xl p-8 border-2 border-blue-400/50 mb-6 h-64 flex flex-col items-center justify-center relative overflow-hidden backdrop-blur-xl"
              whileHover={{ borderColor: 'rgba(96, 165, 250, 0.8)', boxShadow: '0 0 40px rgba(59, 130, 246, 0.3)' }}
              transition={{ duration: 0.3 }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-blue-400/10 to-cyan-400/5"
                animate={{ opacity: [0.4, 0.8, 0.4] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <motion.div className="mb-4 relative z-10" animate={{ y: [0, -10, 0] }} transition={{ duration: 3, repeat: Infinity }}>
                <Droplet className="w-16 h-16 text-blue-300" />
              </motion.div>
              <div className="text-center relative z-10">
                <p className="text-sm font-semibold text-blue-200 mb-2">Hawk Purified Water</p>
                <div className="text-xs text-blue-300/80 space-y-1">
                  <p>• Crystal clear</p>
                  <p>• Perfect mineral balance</p>
                  <p>• Fresh, clean taste</p>
                </div>
              </div>
            </motion.div>
            <motion.div className="space-y-2">
              <p className="text-sm font-semibold text-white">Our Results:</p>
              <ul className="space-y-2">
                {['Crystal clear water', 'Fresh, healthy taste', 'Appliance protection'].map((result, i) => (
                  <motion.li
                    key={result}
                    className="flex items-start gap-2 text-sm text-white/70"
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                  >
                    <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    <span>{result}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          </motion.div>
        </div>

        {/* CTA */}
        <div className="hawk-water-cta">
          <div className="hawk-water-cta-content">
            <h3 className="hawk-water-cta-title">Get Your Free Water Test Today</h3>
            <p className="hawk-water-cta-description">
              Discover exactly what&apos;s in your water with our certified lab analysis
            </p>
            <button className="hawk-button">
              Schedule Free Test
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
