'use client'

import { Phone, MapPin, Clock } from 'lucide-react'

function HawkMark() {
  return (
    <svg
      viewBox="0 0 64 64"
      aria-hidden="true"
      style={{ width: '28px', height: '28px', color: 'var(--hawk-gold)' }}
    >
      <path
        d="M32 31C22 17 10 13 3 13c5 9 12 15 22 19-8-1-14 1-19 5 8 3 15 4 23 1l3 13 3-13c8 3 15 2 23-1-5-4-11-6-19-5 10-4 17-10 22-19-7 0-19 4-29 18Z"
        fill="currentColor"
      />
      <path
        d="m25 48 7 8 7-8-7 3-7-3Z"
        fill="currentColor"
        opacity=".75"
      />
    </svg>
  )
}

export function Footer() {
  return (
    <footer id="contact" className="hawk-section" style={{ backgroundColor: 'var(--hawk-dark)', borderTop: '1px solid var(--hawk-border)' }}>
      <div className="hawk-section-inner">
        {/* Main Footer Content */}
        <div className="hawk-footer-grid">
          {/* Brand Column */}
          <div className="hawk-footer-column">
            <div className="hawk-footer-brand">
              <HawkMark />
              <span className="hawk-footer-brand-text">HAWK DRILLING</span>
            </div>
            <p className="hawk-footer-description">
              5th generation family expertise in water well drilling and treatment since 1927.
            </p>
            <div className="hawk-footer-badges">
              <div className="hawk-footer-badge">NGWA Member</div>
              <div className="hawk-footer-badge">WBENC Certified</div>
              <div className="hawk-footer-badge">Licensed & Insured</div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="hawk-footer-column">
            <h4 className="hawk-footer-heading">Quick Links</h4>
            <ul className="hawk-footer-links">
              <li>
                <a href="#services">Services</a>
              </li>
              <li>
                <a href="#why-us">Why Us</a>
              </li>
              <li>
                <a href="#testimonials">Testimonials</a>
              </li>
              <li>
                <a href="#">About</a>
              </li>
            </ul>
          </div>

          {/* Services Links */}
          <div className="hawk-footer-column">
            <h4 className="hawk-footer-heading">Services</h4>
            <ul className="hawk-footer-links">
              <li>
                <a href="#">Water Well Drilling</a>
              </li>
              <li>
                <a href="#">Pumps & Systems</a>
              </li>
              <li>
                <a href="#">Water Treatment</a>
              </li>
              <li>
                <a href="#">Water Testing</a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="hawk-footer-column">
            <h4 className="hawk-footer-heading">Contact</h4>
            <div className="hawk-footer-contacts">
              <div className="hawk-footer-contact-item">
                <Phone className="hawk-footer-contact-icon" />
                <div>
                  <p className="hawk-footer-contact-label">24/7 Emergency</p>
                  <a href="tel:+18884295011" className="hawk-footer-contact-link">
                    (888) 429-5011
                  </a>
                </div>
              </div>
              <div className="hawk-footer-contact-item">
                <MapPin className="hawk-footer-contact-icon" />
                <div>
                  <p className="hawk-footer-contact-label">Address</p>
                  <p className="hawk-footer-contact-text">123 Main Street, Albany, NY</p>
                </div>
              </div>
              <div className="hawk-footer-contact-item">
                <Clock className="hawk-footer-contact-icon" />
                <div>
                  <p className="hawk-footer-contact-label">Hours</p>
                  <p className="hawk-footer-contact-text">M-F: 8:00 AM - 4:30 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="hawk-footer-divider"></div>

        {/* Bottom Footer */}
        <div className="hawk-footer-bottom">
          <p>&copy; 2024 Hawk Drilling. All rights reserved.</p>
          <div className="hawk-footer-legal">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
