'use client'

import { motion } from 'framer-motion'
import { Droplet, Zap, Beaker, TestTube, ArrowRight } from 'lucide-react'
import { animationVariants, scrollAnimationOptions } from '@/lib/animations'
import { InteractiveServiceCard } from '@/components/interactive-service-card'

export function Services() {
  const services = [
    {
      icon: Droplet,
      title: 'Water Well Drilling',
      description: 'Deep bedrock wells, gravel wells, hydrofracturing',
      features: ['Professional drilling services', '20-year warranty', 'Expert technicians'],
    },
    {
      icon: Zap,
      title: 'Well Pumps & Systems',
      description: 'Submersible pumps, constant pressure systems',
      features: ['5-year pump warranty', 'System optimization', 'Maintenance support'],
    },
    {
      icon: Beaker,
      title: 'Water Treatment & Filtration',
      description: 'Eco-friendly water softeners, iron/sulfur removal',
      features: ['UV purification', 'Bacteria removal', 'Water quality guarantee'],
    },
    {
      icon: TestTube,
      title: 'Water Testing & Lab Analysis',
      description: 'Certified lab screening, bacteria check',
      features: ['Free hardness test', 'Full chemical analysis', 'Certification included'],
    },
  ]

  return (
    <section id="services" className="hawk-section hawk-services-section">
      <div className="hawk-section-inner">
        {/* Section Header */}
        <motion.div
          className="hawk-section-header"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          <motion.div className="hawk-section-eyebrow" variants={animationVariants.itemVariants}>
            COMPREHENSIVE SOLUTIONS
          </motion.div>
          <motion.h2 className="hawk-section-title" variants={animationVariants.itemVariants}>
            Complete Water Well <em>Solutions</em>
          </motion.h2>
          <motion.p className="hawk-section-description" variants={animationVariants.itemVariants}>
            From drilling to testing, we provide complete water well services backed by decades of expertise
          </motion.p>
        </motion.div>

        {/* Services Grid */}
        <motion.div
          className="hawk-services-grid"
          {...scrollAnimationOptions}
          variants={animationVariants.containerVariants}
        >
          {services.map((service, index) => (
            <InteractiveServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              features={service.features}
            />
          ))}
        </motion.div>
      </div>
    </section>
  )
}
