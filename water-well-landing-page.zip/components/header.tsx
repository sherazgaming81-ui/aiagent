'use client'

import { motion } from 'framer-motion'
import { Droplet, Phone } from 'lucide-react'

export function Header() {
  const navLinks = [
    { label: 'Services', href: '#services' },
    { label: 'Why Us', href: '#why-us' },
    { label: 'Testimonials', href: '#testimonials' },
    { label: 'Contact', href: '#contact' },
  ]

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-md bg-slate-900/40 border-b border-white/10 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-primary rounded-lg flex items-center justify-center shadow-lg">
              <Droplet className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-bold text-lg text-white">HAWK</div>
              <div className="text-xs text-white/60">DRILLING</div>
            </div>
          </motion.div>

          {/* Navigation Links */}
          <nav className="hidden md:flex gap-8">
            {navLinks.map((link, i) => (
              <motion.a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-white/80 hover:text-accent transition-colors"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ color: '#F59E0B', scale: 1.05 }}
              >
                {link.label}
              </motion.a>
            ))}
          </nav>

          {/* Emergency Badge */}
          <motion.div
            className="flex items-center gap-3 bg-accent/20 backdrop-blur-md px-4 py-2 rounded-full border border-accent/40"
            animate={{ boxShadow: ['0 0 0 0 rgba(245, 158, 11, 0.4)', '0 0 0 12px rgba(245, 158, 11, 0)'] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <motion.div className="w-2 h-2 bg-accent rounded-full" animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 1.5, repeat: Infinity }} />
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-accent" />
              <a
                href="tel:+15185550199"
                className="text-sm font-semibold text-white hover:text-accent transition-colors whitespace-nowrap"
              >
                24/7: (518) 555-0199
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </header>
  )
}
