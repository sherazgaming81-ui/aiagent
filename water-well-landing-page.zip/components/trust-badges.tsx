'use client'

import { motion } from 'framer-motion'
import { ShieldCheck, Award, Beaker } from 'lucide-react'

export function TrustBadges() {
  const badges = [
    {
      icon: ShieldCheck,
      label: 'NGWA Member',
      description: 'National Ground Water Association',
    },
    {
      icon: Award,
      label: 'Licensed Rig Operators',
      description: 'State certified professionals',
    },
    {
      icon: Beaker,
      label: 'Certified Testing Lab',
      description: 'Full chemical analysis certified',
    },
  ]

  return (
    <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
      {badges.map((badge, i) => {
        const Icon = badge.icon
        return (
          <motion.div
            key={badge.label}
            className="flex items-center gap-3 bg-accent/10 backdrop-blur-md px-5 py-3 rounded-full border border-accent/40 hover:border-accent/60 transition-all"
            whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(245, 158, 11, 0.2)' }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Icon className="w-5 h-5 text-accent flex-shrink-0" />
            <div className="text-left">
              <p className="text-xs font-bold text-accent uppercase tracking-wider">{badge.label}</p>
              <p className="text-xs text-white/60">{badge.description}</p>
            </div>
          </motion.div>
        )
      })}
    </div>
  )
}
