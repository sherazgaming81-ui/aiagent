'use client'

import { motion } from 'framer-motion'
import { MapPin } from 'lucide-react'

export function ServiceArea() {
  const serviceHubs = [
    { name: 'Albany', x: '30%', y: '35%' },
    { name: 'Saratoga Springs', x: '40%', y: '28%' },
    { name: 'Glens Falls', x: '50%', y: '20%' },
    { name: 'Troy', x: '38%', y: '40%' },
  ]

  const counties = [
    'Albany County',
    'Saratoga County',
    'Washington County',
    'Rensselaer County',
    'Dutchess County',
    'Greene County',
    'Columbia County',
    'Warren County',
    'Schenectady County',
    'Montgomery County',
  ]

  return (
    <section className="hawk-section">
      <div className="hawk-section-inner">
        {/* Section Header */}
        <div className="hawk-section-header">
          <div className="hawk-section-eyebrow">SERVICE COVERAGE</div>
          <h2 className="hawk-section-title">
            Service Area & <em>Geographic</em> Coverage
          </h2>
          <p className="hawk-section-description">
            Proudly serving 10+ counties across the capital region with 24/7 emergency response
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map/Grid Section */}
          <motion.div
            className="lg:col-span-2 relative"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <div className="relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 rounded-2xl border border-white/10 backdrop-blur-xl p-8 h-96 overflow-hidden">
              {/* Interactive Map Grid */}
              <svg className="absolute inset-0 w-full h-full opacity-20">
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(245,158,11,0.1)" strokeWidth="0.5" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>

              {/* Service Hubs with Pulsing Dots */}
              {serviceHubs.map((hub, i) => (
                <motion.div
                  key={hub.name}
                  className="absolute flex flex-col items-center"
                  style={{ left: hub.x, top: hub.y }}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.15 }}
                >
                  {/* Pulsing rings */}
                  <motion.div
                    className="absolute w-16 h-16 rounded-full border border-accent/30"
                    animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
                    transition={{ duration: 2.5, repeat: Infinity }}
                  />
                  <motion.div
                    className="absolute w-12 h-12 rounded-full border border-accent/50"
                    animate={{ scale: [1, 1.3, 1], opacity: [1, 0.5, 1] }}
                    transition={{ duration: 2.5, repeat: Infinity, delay: 0.2 }}
                  />

                  {/* Center dot */}
                  <motion.div
                    className="relative w-4 h-4 bg-gradient-to-r from-accent to-amber-600 rounded-full shadow-lg"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />

                  {/* Label */}
                  <motion.span
                    className="mt-8 text-xs font-bold text-white bg-slate-950/80 backdrop-blur px-2 py-1 rounded-full whitespace-nowrap"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.15 + 0.2 }}
                  >
                    {hub.name}
                  </motion.span>
                </motion.div>
              ))}

              {/* Coverage overlay text */}
              <div className="absolute bottom-4 right-4 text-xs text-white/40 flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                <span>10+ Counties Covered</span>
              </div>
            </div>
          </motion.div>

          {/* Counties List */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="bg-gradient-to-br from-accent/10 to-transparent rounded-2xl border border-accent/40 backdrop-blur-xl p-6 h-96 overflow-hidden">
              <h3 className="text-sm font-bold text-accent uppercase tracking-wider mb-4">Counties Served</h3>

              <div className="space-y-2 overflow-y-auto h-full pr-2 custom-scrollbar">
                {counties.map((county, i) => (
                  <motion.div
                    key={county}
                    className="flex items-center gap-2 text-white/70 hover:text-white transition-colors p-2 rounded hover:bg-white/5"
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <div className="w-2 h-2 rounded-full bg-accent flex-shrink-0" />
                    <span className="text-sm">{county}</span>
                  </motion.div>
                ))}
              </div>

              {/* 24/7 Badge */}
              <motion.div
                className="absolute bottom-4 left-4 right-4 bg-gradient-to-r from-accent/20 to-transparent rounded-lg border border-accent/40 p-3 text-center"
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <p className="text-xs font-bold text-accent">24/7 EMERGENCY SERVICE</p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(245, 158, 11, 0.3);
          border-radius: 2px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(245, 158, 11, 0.5);
        }
      `}</style>
    </section>
  )
}
